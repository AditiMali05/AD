package com.example.fragment;

public interface OnButtonPressListener {
    public void onButtonPressed(String msg);

}
