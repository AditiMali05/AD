package com.example.fragment;

import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends FragmentActivity implements OnButtonPressListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        FirstFragment firstFragment = new FirstFragment();
        fragmentTransaction.add(R.id.linearlayout01, firstFragment);
        fragmentTransaction.commit();

        SecondFragment secondFragment = new SecondFragment();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.linearlayout02, secondFragment);
        fragmentTransaction.commit();
    }

    @Override

    public void onButtonPressed(String msg) {

        SecondFragment Obj = (SecondFragment) getSupportFragmentManager().findFragmentById(R.id.linearlayout02);

        assert Obj != null;

        Obj.onFragmentInteraction(msg);

    }
}